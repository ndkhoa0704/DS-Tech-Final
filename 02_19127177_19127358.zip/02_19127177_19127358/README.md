# DS-Tech-Final
* School final project
* Explore data from Walmart
* Source: ```https://www.kaggle.com/yasserh/walmart-dataset```
___
# Meeting log
https://trello.com/b/kr60eGtm/p4ds
